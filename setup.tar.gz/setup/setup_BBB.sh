#!/bin/bash -e

sudo locale-gen en_US.UTF-8

## setup wifi
echo "Setting up wifi"
sudo cp interfaces /etc/network/interfaces
sudo cp wpa_supplicant.conf /etc/wpa_supplicant/
sudo cp issue.net /etc

## setup udev
echo "Setting up udev"
sudo cp 99-swan.rules /etc/udev/rules.d/


## setup gpio
echo "Setting up gpio"
sudo cp configbeagle /etc/
sudo chmod u+x /etc/configbeagle
sudo cp configbeagle.service /lib/systemd/system
sudo systemctl enable configbeagle.service
sudo systemctl start configbeagle.service

## reboot
echo "Please reboot"
