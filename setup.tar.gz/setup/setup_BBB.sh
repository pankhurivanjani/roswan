#!/bin/bash -e

sudo locale-gen en_US.UTF-8
## Make sure there is ethernet connection
cd
mkdir -p catkin_ws/src
cd catkin_ws/src/
git clone https://github.com/subnero1/roswan.git
cd roswan
git checkout develop/BBB
cd setup

## setup wifi
echo "Setting up wifi"
sudo cp interfaces /etc/network/interfaces
sudo cp wpa_supplicant.conf /etc/wpa_supplicant/
sudo cp issue.net /etc

## setup udev
echo "Setting up udev"
sudo cp 99-swan.rules /etc/udev/rules.d/


## setup gpio
echo "Setting up gpio"
sudo cp configbeagle /etc/
sudo chmod u+x /etc/configbeagle
sudo cp configbeagle.service /lib/systemd/system
sudo systemctl enable configbeagle.service
sudo systemctl start configbeagle.service

## reboot
echo "Please reboot"
