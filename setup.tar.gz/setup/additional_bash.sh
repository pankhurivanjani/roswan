source ~/catkin_ws/devel/setup.bash
alias roshome="roscd && cd ../"
alias swh="cd ~/catkin_ws/src/roswan"
alias roshostlocal='export ROS_MASTER_URI=http://192.168.6.2:11311 && export ROS_HOSTNAME=192.168.6.2'
alias roshostswanSub='export ROS_MASTER_URI=http://192.168.0.52:11311 && export ROS_HOSTNAME=192.168.0.52'
alias roshostswan3G='export ROS_MASTER_URI=http://192.168.43.52:11311 && export ROS_HOSTNAME=192.168.43.52'
alias roshostswanAngsa='export ROS_MASTER_URI=http://192.168.1.53:11311 && export ROS_HOSTNAME=192.168.1.53'
alias rosdep_install_all="rosdep install --from-paths src --ignore-src --rosdistro=kinetic -y"
roshostswanAngsa
#roshostswanSub
#roshostlocal
export THRUSTER=trex_driver
export IMU=os5000
export GPS=gps
export CONTROLLER=diff_controller
export MAP=pandan
