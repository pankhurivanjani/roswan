#!/bin/bash -e
cd ~/catkin_ws
rosdep install --from-paths src --ignore-src --rosdistro=kinetic -y
catkin_make
cat additional_bash.sh >> ~/.bashrc
## Force color prompt
sed -i 's/#force_color_prompt=yes/force_color_prompt=yes/g' .bashrc
