#!/bin/bash -e

## Initialize catkin workspace
cd
mkdir -p catkin_ws/src/
cd ~/catkin_ws/src/

## Clone the roswan source code
git clone https://github.com/subnero1/roswan.git
git checkout origin/develop/BBB
cd ../

## Install ros dependencies
rosdep install --from-paths src --ignore-src --rosdistro=kinetic -y

## Build the source code
catkin_make

## Configure env variables
cat ~/setup/additional_bash.sh >> ~/.bashrc

## Force color prompt
sed -i 's/#force_color_prompt=yes/force_color_prompt=yes/g' .bashrc
