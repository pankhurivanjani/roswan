#!/bin/bash -e
## downgrade kernel to 4.4.x
sudo apt udpate && sudo apt -y install linux-image-4.4.132-bone-rt-r22
echo "Please reboot"
