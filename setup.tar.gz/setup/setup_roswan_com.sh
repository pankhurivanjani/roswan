#!/bin/bash -e

## Initialize catkin workspace
cd
mkdir -p catkin_ws/src/
cd ~/catkin_ws/src/

## Clone the roswan source code
git clone https://github.com/subnero1/roswan.git
git checkout origin/develop/remote_com
cd ../

## Install ros dependencies
rosdep install --from-paths src --ignore-src --rosdistro=kinetic -y

## Build the source code
catkin_make

